/// <reference path="../../../scripts/typings/jquery/jquery.d.ts" />
/// <reference path="../../../scripts/typings/knockout/knockout.d.ts" />
/// <reference path="../../../scripts/typings/knockout.validation/knockout.validation.d.ts" />
/// <reference path="../../../scripts/typings/knockout.mapping/knockout.mapping.d.ts" />
var WorkOrderCreationNav = (function () {
    function WorkOrderCreationNav() {
    }
    WorkOrderCreationNav.myTimeStamp = function () {
        var tstmp = new Date();
        return tstmp.getTime();
    };
    // commented out for future use of single sign on
    //public static goToTitleSolutionsWoCreation(url, serviceId) {
    //    $.ajax({
    //        url: "/Admin/GetSamlResponse", // + "&" + new Date().getTime(),
    //        async: false,
    //        type: 'GET',
    //        success: (data) => {
    //            var token = data.Response;
    //            //url.setRequestHeader("SAMLResponse", token);
    //            //url.setRequestHeader("UrlReferrer", url + "SPE/CoreTrack/CreateNewWorkOrder?serviceType=" + serviceId);
    //            //var winToOpen = window.open(url + "Login/Login/Index");
    //            //var xhr = new XMLHttpRequest();
    //            //xhr.setRequestHeader("SAMLResponse", token);
    //            //window.open(url + "Login/Login/LoginFromCoreTrack/?ServiceId=" + serviceId.toString() + "&Token=" + token, "_blank");
    //            $('#NavForm1').empty();
    //            $('#NavForm1').append("<input type = 'hidden' id = 'txtxuser' name = 'txtxuser' value ='iaatpuser' />");
    //            $('#NavForm1').append("<input type = 'hidden' id = 'SAMLResponse' name = 'SAMLResponse' value ='" + token + "' />");
    //            $('#NavForm1').append("<input type = 'hidden' id = 'RelayState' name = 'RelayState' value ='' />");
    //            //$('#NavForm1').append("<input type = 'hidden' id = 'CurrentPage' name = 'CurrentPage' value ='" + this.page() + "' />");
    //            //$('#NavForm1').append("<input type = 'hidden' id = 'PageSize' name = 'PageSize' value ='0' />");
    //            $('#NavForm1').attr("action", url + "Login/Login/Index");
    //            $('#NavForm1').submit();
    //            return true;
    //        }
    //    });
    //}
    WorkOrderCreationNav.goToWoCreation = function (url, serviceId) {
        $.ajax({
            url: "/Admin/GetEncryptedRedirectString?serviceTypeId=" + serviceId,
            async: false,
            type: 'GET',
            success: function (data) {
                $('#NavForm2').empty();
                $('#NavForm2').append("<input type = 'hidden' id = 'encryptedString' name = 'encryptedString' value ='" + data + "' />");
                $('#NavForm2').attr("action", url + "Login/Login/Index");
                $('#NavForm2').attr("target", "_blank");
                $('#NavForm2').submit();
            }
        });
    };
    return WorkOrderCreationNav;
})();
//# sourceMappingURL=WorkOrderCreationNav.js.map