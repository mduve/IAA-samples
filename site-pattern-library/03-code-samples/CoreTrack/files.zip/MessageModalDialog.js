/// <reference path="../../../scripts/typings/jquery/jquery.d.ts" />
/// <reference path="../../../scripts/typings/knockout/knockout.d.ts" />
/// <reference path="../../../scripts/typings/knockout.validation/knockout.validation.d.ts" />
/// <reference path="../../../scripts/typings/knockout.mapping/knockout.mapping.d.ts" />
var MessageModalDialog = (function () {
    function MessageModalDialog(modalDialogId) {
        this.modalDialogId = ko.observable("");
        this.messageHeader = ko.observable(null);
        this.message = ko.observable(null);
        this.showOKButton = ko.observable(false);
        this.showCancelButton = ko.observable(true);
        this.oKButtonText = ko.observable("OK");
        this.cancelButtonText = ko.observable("Cancel");
        var messageModel = this;
        //initialise variables
        messageModel.modalDialogId(modalDialogId);
        //end of initialise variables
        //define methods
        messageModel.initModalDialog = function () {
            var modalDiv = $("#" + messageModel.modalDialogId());
            if (modalDiv.length > 0) {
                modalDiv.modal({ backdrop: "static", keyboard: false, show: false });
            }
        };
        messageModel.setMessage = function (message) {
            messageModel.message(message);
        };
        //sets up handler method to fire after modal is hidden 
        messageModel.setOnModalHiddenHandler = function (onModalHiddenHandler) {
            var modalDiv = $("#" + messageModel.modalDialogId());
            if (modalDiv.length > 0) {
                modalDiv.off('hidden.bs.modal'); //unbind previous event handler
                modalDiv.on('hidden.bs.modal', onModalHiddenHandler); //bind new event handler
            }
        };
        messageModel.showMessageModal = function () {
            var modalDiv = $("#" + messageModel.modalDialogId());
            if (modalDiv.length > 0) {
                modalDiv.modal("show");
            }
        };
        messageModel.hideMessageModal = function () {
            var modalDiv = $("#" + messageModel.modalDialogId());
            if (modalDiv.length > 0) {
                modalDiv.modal("hide");
            }
        };
        messageModel.okButtonClick = function () {
            messageModel.hideMessageModal();
        };
        messageModel.cancelButtonClick = function () {
            messageModel.hideMessageModal();
        };
        //call below method to set custom handlers for OK and Cancel buttons on modal popup
        messageModel.setButtonClickEventHandlers = function (okButtonClickHandler, cancelButtonClickHandler) {
            messageModel.okButtonClick = okButtonClickHandler;
            messageModel.cancelButtonClick = cancelButtonClickHandler;
        };
        messageModel.setMesssageModal = function (messageHeader, message, showOKButton, oKButtonText, showCancelButton, cancelButtonText, okButtonClickHandler, cancelButtonClickHandler, openMessageModal, onModalHiddenHandler) {
            messageModel.messageHeader(messageHeader);
            messageModel.message(message);
            messageModel.showOKButton(showOKButton);
            messageModel.showCancelButton(showCancelButton);
            messageModel.oKButtonText(oKButtonText);
            messageModel.cancelButtonText(cancelButtonText);
            messageModel.setButtonClickEventHandlers(okButtonClickHandler, cancelButtonClickHandler);
            messageModel.setOnModalHiddenHandler(onModalHiddenHandler);
            if (openMessageModal) {
                messageModel.showMessageModal();
            }
        };
        MessageModalDialog.getMessageModalDialogContext = function (modalDialogId) {
            var context = null;
            var modalDiv = $("#" + $.trim(modalDialogId));
            if (modalDiv.length > 0) {
                var data = ko.dataFor(modalDiv[0]);
                if (typeof data != "undefined" && data != null) {
                    context = data;
                }
            }
            return context;
        };
        //end of define methods
        //initialise modal dialog
        messageModel.initModalDialog();
    }
    return MessageModalDialog;
})();
//# sourceMappingURL=messagemodaldialog.js.map