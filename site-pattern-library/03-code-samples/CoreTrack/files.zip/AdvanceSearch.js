var CommonConstant = (function () {
    function CommonConstant() {
    }
    CommonConstant.SearchHistorycount = 10;
    return CommonConstant;
})();
var SearchInput = (function () {
    function SearchInput() {
    }
    return SearchInput;
})();
var AdvanceSearch = (function () {
    function AdvanceSearch() {
        var _this = this;
        this.CurrentTab = ko.observable("General");
        this.OwnerLastName = ko.observable("");
        this.Provider = ko.observable("");
        this.Adjuster = ko.observable("");
        this.Workorder = ko.observable("");
        this.Stock = ko.observable("");
        this.Claim = ko.observable("");
        this.Handler = ko.observable("");
        this.VIN = ko.observable("")
            .extend({
            required: {
                params: true,
                message: "Service Type is required",
                onlyIf: function () {
                    return (_this.CurrentTab() == "VIN");
                }
            },
            notify: "always"
        });
        this.SearchHistoryList = ko.observableArray([]);
        this.searchByValue = ko.observable("");
        this.address1 = ko.observable("")
            .extend({
            minLength: {
                params: 3,
                message: "Provide at least 3 characters",
                onlyIf: function () {
                    return (_this.CurrentTab() == "Owner" && _this.address1() != null && _this.address1().length > 0);
                }
            },
            notify: "always"
        });
        this.address2 = ko.observable("")
            .extend({
            minLength: {
                params: 3,
                message: "Provide at least 3 characters",
                onlyIf: function () {
                    return (_this.CurrentTab() == "Owner" && _this.address2() != null && _this.address2().length > 0);
                }
            },
            notify: "always"
        });
        this.zip = ko.observable("")
            .extend({
            minLength: {
                params: 5,
                message: "Provide at least 5 characters",
                onlyIf: function () {
                    return (_this.CurrentTab() == "Owner" && _this.zip() != null && _this.zip().length > 0);
                }
            },
            notify: "always"
        });
        this.hidePopUp = function () {
            $('#advancedSearch').modal('hide');
            AdvanceSearch.WorkOrderStatus([]);
            AdvanceSearch.lossStates([]);
            _this.Workorder("");
            _this.Provider("");
            _this.Adjuster("");
            _this.Workorder("");
            _this.Stock("");
            _this.Claim("");
            _this.VIN("");
            _this.OwnerLastName("");
            _this.address1("");
            _this.address2("");
            _this.zip("");
            _this.Handler("");
        };
        this.getAdvanceSearchResult = function () {
            if (_this.searchValidationErrors().length > 0) {
                _this.searchValidationErrors.showAllMessages();
                _this.showAllSearchValidationMessages();
            }
            else {
                $('#viewloader').show();
                var sAction;
                var SearchText = '';
                var Action = 'SearchResult';
                //var search = {};
                var search = [{}];
                var obj = new SearchInput();
                obj.workOrderId = _this.Workorder();
                obj.titlestate = AdvanceSearch.selLossState() == "undefined" ? "" : AdvanceSearch.selLossState();
                obj.provider = _this.Provider();
                obj.workorderstatus = AdvanceSearch.WOStatus() == "undefined" ? "" : AdvanceSearch.WOStatus();
                obj.adjustername = _this.Adjuster();
                obj.handlername = _this.Handler();
                obj.workorder = _this.Workorder();
                obj.stock = _this.Stock();
                obj.claim = _this.Claim();
                obj.vin = _this.VIN();
                obj.lastName = _this.OwnerLastName();
                obj.address1 = _this.address1();
                obj.address2 = _this.address2();
                obj.zip = _this.zip();
                $('#advancedSearch').modal('hide');
                if (_this.CurrentTab() == 'General') {
                    //SearchText = "OwnerLastName=" + obj.ownerlastname + ", TitleState=" + obj.titlestate.toString() + ",ProviderName=" + obj.provider + ", Status=" + obj.workorderstatus + ",Adjuster=" + obj.adjustername + ", WorkOrderId = " + obj.workorder + ", StockNumber = " + obj.stock + ", ClaimNumber = " + obj.claim + ", VIN = " + obj.vin 
                    if (obj.workOrderId.toString().trim() != "") {
                        //search["OwnerLastName"] = obj.ownerlastname.toString().trim();
                        search.push({ Key: "WorkOrderId", Value: obj.workOrderId.toString().trim() });
                    }
                    if (obj.titlestate != null)
                        search.push({ Key: "TitleState", Value: obj.titlestate.toString().trim() });
                    //search["TitleState"] = obj.titlestate.toString().trim();
                    if (obj.provider.toString().trim() != "")
                        search.push({ Key: "ProviderName", Value: obj.provider.toString().trim() });
                    if (obj.workorderstatus != null)
                        search.push({ Key: "Status", Value: obj.workorderstatus.toString().trim() });
                    if (obj.adjustername.toString().trim() != "")
                        search.push({ Key: "Adjuster", Value: obj.adjustername.toString().trim() });
                    if (obj.handlername.toString().trim() != "")
                        search.push({ Key: "HandlerName", Value: obj.handlername.toString().trim() });
                    Action = 'AdvanceSearch';
                }
                else if (_this.CurrentTab() == 'Owner') {
                    if (obj.lastName.toString().trim() != "") {
                        search.push({ Key: "OwnerLastName", Value: obj.lastName.toString().trim() });
                    }
                    if (obj.address1.toString().trim() != "") {
                        search.push({ Key: "ClaimantAddress1", Value: obj.address1.toString().trim() });
                    }
                    if (obj.address2.toString().trim() != "") {
                        search.push({ Key: "ClaimantAddress2", Value: obj.address2.toString().trim() });
                    }
                    if (obj.zip.toString().trim() != "") {
                        search.push({ Key: "ClaimantZip", Value: obj.zip.toString().trim() });
                    }
                    Action = 'AdvanceSearch';
                }
                else if (_this.CurrentTab() == 'Stock')
                    SearchText = obj.stock;
                else if (_this.CurrentTab() == 'Claim')
                    SearchText = obj.claim;
                else if (_this.CurrentTab() == 'VIN') {
                    if (obj.vin.toString().trim() != "") {
                        search.push({ Key: "VIN", Value: obj.vin.toString().trim() });
                    }
                    Action = 'AdvanceSearch';
                }
                $('#NavForm1').empty();
                $('#NavForm1')
                    .append("<input type = 'hidden' id = 'SearchByValue' name = 'SearchByValue' value = '" +
                    SearchText +
                    "' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'PageSize' name = 'PageSize' value ='25' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'CurrentPage' name = 'CurrentPage' value ='1' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'SortCol' name = 'SortCol' value ='WorkOrderId' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'SortDir' name = 'SortDir' value ='DESC' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'SortFormat' name = 'SortFormat' value ='Numeric' />");
                $('#NavForm1')
                    .append("<input type = 'hidden' id = 'SaveUserSearchHistory' name = 'SaveUserSearchHistory' value ='false' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'Action' name = 'Action' value =" + Action + " />");
                $('#NavForm1')
                    .append("<input type = 'hidden' id = 'SearchByGeneral' name = 'SearchByGeneral' value ='" +
                    ko.toJSON(search) +
                    "' />");
                $('#NavForm1')
                    .append("<input type = 'hidden' id = 'isFirstTimeLoad' name = 'isFirstTimeLoad' value ='" +
                    true +
                    "' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'reportId' name = 'reportId' value ='101' />");
                $('#NavForm1')
                    .append("<input type = 'hidden' id = 'clientApplicationId' name = 'clientApplicationId' value ='14' />");
                $('#NavForm1').attr("action", "/SearchDetail/SearchResult/");
                $('#NavForm1').submit();
            }
        };
        this.getUserSearchHistoryResult();
        this.goToSearch = function (searchText) {
            searchText = $.trim(searchText);
            if (searchText != "" && searchText != null) {
                $('#viewloader').show();
                var saveUserSearchHistory = true;
                $('#NavForm1').empty();
                $('#NavForm1').append("<input type = 'hidden' id = 'SearchByValue' name = 'SearchByValue' value ='" + searchText + "' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'SaveUserSearchHistory' name = 'SaveUserSearchHistory' value ='" + saveUserSearchHistory + "' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'reportId' name = 'reportId' value ='101' />");
                $('#NavForm1').append("<input type = 'hidden' id = 'clientApplicationId' name = 'clientApplicationId' value ='14' />");
                $('#NavForm1').attr("action", "/SearchDetail/SearchResult");
                $('#NavForm1').submit();
                return true;
            }
            return false;
        };
        this.handleEnterKeyPress = function (data, event) {
            var keyCode = event.keyCode ? event.keyCode : event.charCode;
            if (keyCode == 13) {
                if (typeof (window.event) != 'undefined') {
                }
                else {
                    event.preventDefault(); //For Firefox
                }
                this.goToSearch(this.searchByValue());
                return false;
            }
            return true;
        };
        this.showAllSearchValidationMessages = function () {
            $("#advancedSearch .error").next(".error-message").addClass("error-message-display");
        };
        this.searchValidationErrors = ko.validation.group(this.getValidationModel()());
    } //** end of consrtuctor
    AdvanceSearch.myTimeStamp = function () {
        var tstmp = new Date();
        return tstmp.getTime();
    };
    AdvanceSearch.getAdvanceSearchDetailts = function () {
        $("#inpHandlerName").val("");
        $("#inpAdjusterName").val("");
        $('#divSettingsContent a:first').tab('show');
        AdvanceSearch.getWorkOrderStatus();
        AdvanceSearch.getTitleState();
    };
    AdvanceSearch.getTitleState = function () {
        var _this = this;
        var stateList = null;
        this.lossStates([]);
        $.ajax({
            url: "/Dashboard/getTitleState",
            async: false,
            type: 'GET',
            success: function (data) {
                stateList = data;
                if (stateList != null) {
                    var selValue = "", selText = "";
                    if (AdvanceSearch.lossStates.length == 0) {
                        for (var i = 0; i < stateList.length; i++) {
                            selText = stateList[i].StateName.toString();
                            selValue = stateList[i].StateAbbreviation.toString();
                            _this.lossStates.push({ text: selText, value: selValue });
                        }
                    }
                }
            }
        });
    };
    AdvanceSearch.getWorkOrderStatus = function () {
        var _this = this;
        var statusList = null;
        this.WorkOrderStatus([]);
        $.ajax({
            url: "/Dashboard/getWorkOrderStatus",
            async: false,
            type: 'GET',
            success: function (data) {
                statusList = data;
                if (statusList != null) {
                    var selValue = "", selText = "";
                    for (var i = 0; i < statusList.length; i++) {
                        //if (statusList[i].Name.toString() !== "SELECT ONE") {
                        selText = statusList[i].toString();
                        selValue = statusList[i].toString();
                        _this.WorkOrderStatus.push({ text: selText, value: selValue });
                    }
                }
                //ko.cleanNode($('#selWorkOrderStatus').get(0));
                //this.WorkOrderStatus = null;
            }
        });
    };
    AdvanceSearch.prototype.getUserSearchHistoryResult = function () {
        var _this = this;
        this.SearchHistoryList([]);
        $.ajax({
            url: "/Dashboard/GetUserSearchHistoryResult?count=" + CommonConstant.SearchHistorycount + "&" + AdvanceSearch.myTimeStamp(),
            async: false,
            type: 'GET',
            success: function (data) {
                if (data != null && data.length > 0) {
                    for (var j = 0; j < data.length; j++) {
                        var seltext = data[j].SearchText;
                        var selCreateDate = data[j].CreatedDate;
                        _this.SearchHistoryList.push({ searchText: seltext, createdDate: selCreateDate });
                    }
                }
            }
        });
    };
    AdvanceSearch.prototype.getValidationModel = function () {
        var validationModel = {};
        switch (this.CurrentTab()) {
            case "VIN":
                validationModel.VIN = this.VIN;
                break;
            case "Owner":
                validationModel.address1 = this.address1;
                validationModel.address2 = this.address2;
                validationModel.zip = this.zip;
                break;
        }
        return ko.validatedObservable(validationModel);
    };
    AdvanceSearch.prototype.setValidationModel = function () {
        this.searchValidationErrors = ko.validation.group(this.getValidationModel()());
    };
    AdvanceSearch.lossStates = ko.observableArray([]);
    AdvanceSearch.selLossState = ko.observable("");
    AdvanceSearch.WorkOrderStatus = ko.observableArray([]);
    AdvanceSearch.WOStatus = ko.observable("");
    return AdvanceSearch;
})();
//# sourceMappingURL=AdvanceSearch.js.map