﻿$(document).ready(function () {

    //  GLOBAL SCOPE FUNCTIONS

    function removeBodyClasses() {
        $('body').removeClass();
    }

    $('.overlay').on('click', function () {
        removeBodyClasses();
    });

    $('.search-trigger').on('click', function () {
        $('body').toggleClass('search-active').removeClass('menu-active');
    });

    $(window).resize(function () {
        removeBodyClasses();
    });

    
    //$("table").not('.customTableSorter').tablesorter({ sortReset: true });

    //$("table").not('.customTableSorter').bind("sortEnd", function (e, table) {

    //    $("table").find(".tablesorter-headerDesc, .tablesorter-headerAsc").addClass("highlight");
    //    $("table").find(".tablesorter-headerUnSorted, td.highlight").removeClass("highlight");

        

    //    $("table tbody tr").each(function () {

    //        var highlight_index = $("thead .highlight").index();

    //        if (highlight_index >= 0) {
    //            $(this).find('td').eq(highlight_index).addClass('highlight');
    //        } else {
    //            $(this).find('td').removeClass('highlight');
    //        }
    //    });

    //});

    // quick search
    var searchInput = $(".search .search-field")
        ,searchForm = $('form.search')
        ,mousedownHappened = false;

    Mousetrap.bind('ctrl+s', function (e) {
        if (e.preventDefault) {e.preventDefault();} else {e.returnValue = false;}
        searchInput.focus();
    });

    var searchVal = function () {
        $("#recent").addClass("active-view");
        Mousetrap.unbind('ctrl+a');

        Mousetrap.bind('shift+down', function (e) {
            if ($("#recent a").hasClass('active-item') === true) {
                $("#recent a.active-item").nextAll(".group a").eq(0).addClass("active-item");
                $("#recent a.active-item").prevAll(".group a").removeClass("active-item");
            } else {
                $("#recent a").first().addClass("active-item");
            }
        });
        Mousetrap.bind('shift+up', function (e) {
            if ($("#recent a").hasClass('active-item') === true) {
                $("#recent a.active-item").prevAll(".group a").eq(0).addClass("active-item");
                $("#recent a.active-item").nextAll(".group a").removeClass("active-item");
            }
        });
    }

    $(searchInput).on('focus', function () {
        searchVal();
        Mousetrap.unbind('ctrl+a');
    });

    $(searchInput).on('input', function () {
        $(".active-item").removeClass("active-item");
        searchVal();
    });

    $(searchInput).on('blur', function () {
        if (mousedownHappened) {
            mousedownHappened = false;
        } else {
            $(".active-item").removeClass("active-item");
            $(".active-view").removeClass("active-view");
            searchInput.val('');
            Mousetrap.bind('ctrl+a', function (e) {
                event.preventDefault();
                $('#advancedSearch').modal('toggle');
            });
        }
    });
    
    $('.search .search-types a, .search .search-submit').mousedown(function () {
        mousedownHappened = true;
    });

    $("a.advance").click(function () {
        searchInput.blur();
        $("#advancedSearch").modal('show');
    });

    // SCRIPTS FOR ADVANCED SEARCH

    Mousetrap.bind('ctrl+a', function (e) {
        event.preventDefault();
        $('#advancedSearch').modal('toggle');
    });

    // Set and Cache Criteria Variables
    var //critTrash = $('.criteria .icon-trash'),
        //critSelectedItem = $('.criteria-selected li'),
        //critSelectItem = $('.criteria-select li'),
        //critSelected = $(".criteria-selected"),
        //critSelect = $('.criteria-select'),
        //critDefault = $('.criteria .default'),
        //critList = $('.criteria li'),
        //criteria = $('.criteria'),
        //critContainer = $('.criteria-container'),
        //editCriteria = $('.edit-criteria'),
        //editText = $('.edit-criteria > a span'),
        //selectText = "Select Criteria",
        //applyText = "Apply Selected Criteria",
        quickSearch = $('.quick-link'),
        adSearch = $('#advancedSearch');



    // Hide advanced search and enable quick search
    $(quickSearch).on('click', function (e) {
        $(adSearch).modal('hide');
        $(adSearch).on('hidden.bs.modal', function (e) {
            $('.search-field').focus();
        });
    });



    // Function for Removing Menu Levels
    function removeLevels() {
        $('.level').removeClass('active');
    }

    // Function for Activating Slide Out Menu
    function slideMenu() {
        removeLevels();
        $('body').toggleClass('menu-active').removeClass('search-active shortcut-active');
    }



    // SCRIPTS FOR SLIDE OUT MENU
    //function slideMenu() {
    //    $('body').toggleClass('menu-active').removeClass('search-active');
    //}
    //$('.menu-link, .menu .close').on('click', function () {
    //    slideMenu();
    //});

    // Activate Menu on Button Click
    $('.menu-link, .menu .close').on('click', function () {
        slideMenu();
    });

    // Activate Menu with Key Command
    Mousetrap.bind('ctrl+m', function (e) {
        event.preventDefault();
        slideMenu();
    });

    // Click to Go Back a Level
    $('.back').on('click', function () {
        $(this).parent().removeClass('active');
    });

    // If It's Not Disabled Go to the Next Level
    $('.menu .category > a').on('click', function () {
        if (!$(this).hasClass('disabled')) {
            $(this).siblings().addClass('active').parent().siblings().children().removeClass('active');
        }
    });

    // Remove Body Classes on Window Resize
    $(window).resize(function () {
        removeBodyClasses();
        removeLevels();
    });

});




