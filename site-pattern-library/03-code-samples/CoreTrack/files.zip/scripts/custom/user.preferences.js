﻿$(document).ready(function () {

    var stock = $("#t-stock .group label"),
        buyer = $("#t-buyer .group label"),
        provider = $("#t-provider .group label"),
        storage = $("#t-storage .group label");


    $('#userPreferences').on('shown.bs.modal', function (e) {
        $("#t-stock .group").append(stock);
        $("#t-buyer .group").append(buyer);
        $("#t-provider .group").append(provider);
        $("#t-storage .group").append(storage);
    });

    //open keypad shortcut
    Mousetrap.bind('ctrl+u', function (e) {
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        $("#userPreferences").modal('toggle')
    });

    $(".settings-link.sec-button").click(function () {
        $("#userPreferences").modal('show');
    });

    $("#userPreferences #viewInfoBtn").click(function () {
        $("#asap-info").modal('show');
    });
    $("#asap-info").on('shown.bs.modal', function (e) {
        $("body").addClass("modal-open");
    })
    $("#SaveUserPreferencesBtn").click(function () {
        var setTypeSize = $("#setTypeSize").val(),
            defaultStock = $("#defaultStockSelect").val(),
            defaultBuyer = $("#defaultBuyerSelect").val(),
            defaultProvider = $("#defaultProviderSelect").val(),
            defaultStorage = $("#defaultStorageLocationSelect").val();

        var oneDefault = function (tabid) {
            $(tabid + " label").removeClass("active-item");
            $(tabid + " label").removeClass("default").find("span").text("");
            $(tabid + " label").each(function () {
                var thisVal = $(this).children().val();
                if (defaultStock === thisVal || defaultBuyer === thisVal || defaultProvider === thisVal || defaultStorage === thisVal) {
                    if ($(this).is("[data-type='string']")) {
                        $(this).addClass("active-item default").find("span").text("default");
                    } else if ($(this).is("[data-type='number']")) {
                        $(this).addClass("active-item default").find("span").text("default");
                    }
                }

            });
        }
        oneDefault("#t-stock");
        oneDefault("#t-buyer");
        oneDefault("#t-provider");
        oneDefault("#t-storage");

        
        $("#setTypeSize > option").each(function () {
            if (setTypeSize === this.value) {
                $("html").addClass("text-" + setTypeSize);
            } else {
                $("html").removeClass("text-" + this.value);
            }
        });

        if ($("div").hasClass("k-grid") === true) {
            $('#data-grid').data('kendoGrid').refresh();
        }
        
    });
});